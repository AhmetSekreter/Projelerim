package main

import (
	"fmt"
	"kutuphaneodev/auth"
	"kutuphaneodev/config"
	"kutuphaneodev/dbops"
)

func main() {
	config.InitDB()
	defer config.DB.Close()

	fmt.Println("=====================================")
	fmt.Println("  KÜTÜPHANE YÖNETİM SİSTEMİNE HOŞ GELDİNİZ")
	fmt.Println("=====================================")

	for {
		fmt.Println("\n1. Giriş Yap")
		fmt.Println("2. Kayıt Ol")
		fmt.Println("3. Çıkış")
		fmt.Print("Seçiminiz: ")

		var secim int
		fmt.Scanln(&secim)

		if secim == 1 {
			var username, password string
			fmt.Print("Kullanıcı Adı: ")
			fmt.Scanln(&username)
			fmt.Print("Şifre: ")
			fmt.Scanln(&password)

			if auth.Login(username, password) {
				fmt.Println("\nGiriş Başarılı! Sisteme yönlendiriliyorsunuz...")
				kutuphaneMenu() // Ana menüyü aç
				break
			} else {
				fmt.Println("Hatalı kullanıcı adı veya şifre!")
			}
		} else if secim == 2 {
			var username, password string
			fmt.Print("Yeni Kullanıcı Adı: ")
			fmt.Scanln(&username)
			fmt.Print("Yeni Şifre: ")
			fmt.Scanln(&password)

			if auth.Register(username, password) {
				fmt.Println("Kayıt başarılı! Şimdi giriş yapabilirsiniz.")
			} else {
				fmt.Println("Bu kullanıcı adı zaten alınmış!")
			}
		} else if secim == 3 {
			fmt.Println("Programdan çıkılıyor...")
			return
		} else {
			fmt.Println("Geçersiz seçim!")
		}
	}
}

func kutuphaneMenu() {
	for {
		fmt.Println("\n==============================")
		fmt.Println("      YÖNETİM PANELİ")
		fmt.Println("==============================")
		fmt.Println("1. Kitap Ekle")
		fmt.Println("2. Kitapları Listele")
		fmt.Println("3. Kitap Ödünç Ver (Durum Güncelle)")
		fmt.Println("4. Kitap Sil")
		fmt.Println("5. Güvenli Çıkış")
		fmt.Print("İşlem Seçiniz: ")

		var islem int
		fmt.Scanln(&islem)

		switch islem {
		case 1:
			var title, author string
			fmt.Print("Kitap Adı: ")
			fmt.Scanln(&title)
			fmt.Print("Yazar Adı: ")
			fmt.Scanln(&author)
			dbops.AddBook(title, author)
		case 2:
			dbops.ListBooks()
		case 3:
			var id int
			fmt.Print("Ödünç verilecek Kitap ID: ")
			fmt.Scanln(&id)
			dbops.BorrowBook(id)
		case 4:
			var id int
			fmt.Print("Silinecek Kitap ID: ")
			fmt.Scanln(&id)
			dbops.DeleteBook(id)
		case 5:
			fmt.Println("Oturum kapatıldı. Hoşça kalın!")
			return
		default:
			fmt.Println("Geçersiz işlem seçildi!")
		}
	}
}
