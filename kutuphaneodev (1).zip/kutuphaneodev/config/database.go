package config

import (
	"database/sql"
	"log"

	_ "github.com/glebarez/go-sqlite" // CGO gerektirmeyen yeni SQLite sürücüsü
)

var DB *sql.DB

func InitDB() {
	var err error
	// Sürücü adını "sqlite" olarak güncelledik
	DB, err = sql.Open("sqlite", "./kutuphane.db")
	if err != nil {
		log.Fatal("Veritabanı açılamadı:", err)
	}

	userTable := `CREATE TABLE IF NOT EXISTS users (
		id INTEGER PRIMARY KEY AUTOINCREMENT,
		username TEXT UNIQUE,
		password TEXT
	);`

	bookTable := `CREATE TABLE IF NOT EXISTS books (
		id INTEGER PRIMARY KEY AUTOINCREMENT,
		title TEXT,
		author TEXT,
		is_borrowed INTEGER DEFAULT 0
	);`

	_, err = DB.Exec(userTable)
	if err != nil {
		log.Fatal("Kullanıcı tablosu oluşturulamadı:", err)
	}

	_, err = DB.Exec(bookTable)
	if err != nil {
		log.Fatal("Kitap tablosu oluşturulamadı:", err)
	}
}
