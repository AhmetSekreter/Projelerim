package dbops

import (
	"fmt"
	"kutuphaneodev/config"
	"kutuphaneodev/models"
)

func AddBook(title, author string) {
	query := `INSERT INTO books (title, author) VALUES (?, ?)`
	_, err := config.DB.Exec(query, title, author)
	if err != nil {
		fmt.Println("Kitap eklenirken hata oluştu:", err)
		return
	}
	fmt.Println("Kitap başarıyla eklendi!")
}

func ListBooks() {
	query := `SELECT id, title, author, is_borrowed FROM books`
	rows, err := config.DB.Query(query)
	if err != nil {
		fmt.Println("Kitaplar listelenirken hata oluştu:", err)
		return
	}
	defer rows.Close()

	fmt.Println("\n--- KÜTÜPHANEDEKİ KİTAPLAR ---")
	for rows.Next() {
		var b models.Book
		var isBorrowedInt int
		err := rows.Scan(&b.ID, &b.Title, &b.Author, &isBorrowedInt)
		if err != nil {
			fmt.Println("Veri okuma hatası:", err)
			return
		}

		durum := "Rafta (Mevcut)"
		if isBorrowedInt == 1 {
			durum = "Ödünç Verildi"
		}
		fmt.Printf("ID: %d | Kitap: %s | Yazar: %s | Durum: %s\n", b.ID, b.Title, b.Author, durum)
	}
}

func BorrowBook(bookID int) {
	query := `UPDATE books SET is_borrowed = 1 WHERE id = ?`
	_, err := config.DB.Exec(query, bookID)
	if err != nil {
		fmt.Println("Kitap güncellenirken hata oluştu:", err)
		return
	}
	fmt.Println("Kitap başarıyla ödünç verildi!")
}

func DeleteBook(bookID int) {
	query := `DELETE FROM books WHERE id = ?`
	_, err := config.DB.Exec(query, bookID)
	if err != nil {
		fmt.Println("Kitap silinirken hata oluştu:", err)
		return
	}
	fmt.Println("Kitap sistemden tamamen silindi!")
}
