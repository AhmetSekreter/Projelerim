package auth

import (
	"database/sql"
	"kutuphaneodev/config"
)

func Register(username, password string) bool {
	query := `INSERT INTO users (username, password) VALUES (?, ?)`
	_, err := config.DB.Exec(query, username, password)
	if err != nil {
		return false
	}
	return true
}

func Login(username, password string) bool {
	var dbPassword string
	query := `SELECT password FROM users WHERE username = ?`

	err := config.DB.QueryRow(query, username).Scan(&dbPassword)
	if err == sql.ErrNoRows {
		return false
	} else if err != nil {
		return false
	}

	return dbPassword == password
}
